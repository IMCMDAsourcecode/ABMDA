The specific content in ��readme.txt�� has now become:
��Due to the limitation of our experimental conditions, we did not test whether our code could run normally on different computer systems and software. Here, we give the operating environment that makes the program to run normally in our lab.
Operating environment:
Operating system: Windows 10 Home x64
Software: Anaconda 64-Bit Python 3.6 version*
		Specific steps:
(1)	setup the Anaconda 64-Bit Python 3.6 version* (If you have installed, please skip this step)
(2)	find and open the ��spyder.exe�� in the start menu
(3)	open the ��code.py�� you download (Remember not to change the file path)
(4)	find and click the running button or press ��F5�� to run the program
(5)	you will obtain ��Prediction results for all unknown samples.txt��, where there are the disease, miRNA, and score corresponding to the sample in each row.
